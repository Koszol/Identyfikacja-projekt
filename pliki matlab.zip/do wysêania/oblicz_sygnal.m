function [Freq_out,Y_out] = oblicz_sygnal(R,L,C,C0)
    

end

